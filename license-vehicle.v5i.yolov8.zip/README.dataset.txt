# license-vehicle > 2024-12-10 2:24pm
https://universe.roboflow.com/dimas-daffa/license-vehicle

Provided by a Roboflow user
License: CC BY 4.0

